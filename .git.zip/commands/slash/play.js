// FILEPATH: c:/Users/zenge/Downloads/Discord-MusicBot-5/Discord-MusicBot-5/commands/slash/play.js

const SlashCommand = require("../../lib/SlashCommand");
const { EmbedBuilder } = require("discord.js");

const command = new SlashCommand()
  .setName("play")
  .setDescription("搜索並播放請求的歌曲")
  .addStringOption((option) =>
    option
      .setName("query")
      .setDescription("我要搜索什麼？")
      .setRequired(true)
      .setAutocomplete(true)
  )
  .setSelfDefer(true) // 設置 selfDefer 屬性，表示此指令會自行處理延遲回應
  .setRun(async (client, interaction, options) => {
    // 獲取語音頻道
    const voiceChannel = interaction.member.voice.channel;
    if (!voiceChannel) {
        return interaction.reply({
            embeds: [client.ErrorEmbed("您必須在語音頻道中才能使用此命令", "未在語音頻道")],
            flags: 1 << 6 // 使用 flags 而不是 ephemeral
        });
    }

    // 檢查機器人是否有必要權限
    const permissions = voiceChannel.permissionsFor(client.user);
    if (!permissions.has("Connect") || !permissions.has("Speak")) {
        return interaction.reply({
            embeds: [client.ErrorEmbed("我需要語音頻道的連接與說話權限", "權限不足")],
            flags: 1 << 6
        });
    }

    // 獲取要播放的歌曲
    const song = options.getString("query", true);
    if (!song) {
        return interaction.reply({
            embeds: [client.ErrorEmbed("請提供要播放的歌曲名稱或URL", "參數錯誤")],
            flags: 1 << 6
        });
    }
    
    // 立即給用戶一個延遲回應，避免互動超時
    await interaction.deferReply();
    
    try {
        // 處理 YouTube URL，確保格式正確
        let finalSong = song;
        let useYouTubeExtractor = false;
        
        // 檢查是否為 YouTube URL
        if (song.includes('youtube.com/watch') || song.includes('youtu.be/')) {
            useYouTubeExtractor = true;
            
            // 嘗試標準化 YouTube URL 格式
            if (song.includes('youtube.com/watch')) {
                // 從 URL 中提取視頻 ID
                const videoId = song.match(/v=([^&]+)/)?.[1];
                if (videoId) {
                    finalSong = `https://youtu.be/${videoId}`;
                    console.log(`已將 YouTube URL 標準化為: ${finalSong}`);
                }
            }
        }
        
        console.log(`開始播放: ${finalSong} (使用 YouTube 提取器: ${useYouTubeExtractor})`);
        
        // 嘗試播放歌曲
        const result = await client.player.play(voiceChannel, finalSong, {
            nodeOptions: {
                metadata: interaction,
                leaveOnEmpty: client.config.autoLeave,
                leaveOnEnd: client.config.autoLeave,
                volume: client.config.defaultVolume
            },
            // 使用字串而非陣列
            searchEngine: useYouTubeExtractor ? 'youtube' : 'auto'
        });
        
        // 我們不需要在這裡回應，因為 playerStart 事件會處理顯示正在播放的內容
        
    } catch (error) {
        console.error(`播放錯誤:`, error);
        
        // 處理錯誤回應
        const errorMessage = error.code === 'ERR_NO_RESULT'
            ? `找不到歌曲: ${song}\n可能原因：URL 無效、影片已移除或是因為地區限制而無法播放`
            : `播放失敗: ${error.message}`;
        
        // 使用 editReply 回應已經延遲的互動
        await interaction.editReply({
            content: `❌ ${errorMessage}`
        }).catch(console.error);
    }
  });

module.exports = command;