# License for Yinkan MusicBot

- **Credits must remain intact**. Any modification or removal of original credits is strictly prohibited.
- This bot is intended solely for **private hosting** and **personal use**.
- **Public deployment or usage** of this bot is **not permitted** under this license.

> **Notice:** Any breach of the above terms may result in a takedown request.  
> Thank you for respecting the license – enjoy your music!  
> For clarification or inquiries, please contact the project owner.
